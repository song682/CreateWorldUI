package decok.dfcdvadstf.createworldui.mixin;

import decok.dfcdvadstf.createworldui.api.TabState;
import decok.dfcdvadstf.createworldui.editor.GameRuleEditor;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiButton;
import net.minecraft.client.gui.GuiCreateWorld;
import net.minecraft.client.gui.GuiScreen;
import net.minecraft.client.gui.GuiTextField;
import net.minecraft.client.resources.I18n;
import net.minecraft.util.ResourceLocation;
import net.minecraft.world.WorldSettings;
import net.minecraft.world.WorldType;
import net.minecraft.world.EnumDifficulty;
import net.minecraft.world.storage.WorldInfo;
import org.apache.logging.log4j.Logger;
import org.lwjgl.input.Keyboard;
import org.spongepowered.asm.mixin.*;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.List;

import static decok.dfcdvadstf.createworldui.api.util.TextureHelper.drawModalRectWithCustomSizedTexture;

@SuppressWarnings("unchecked")
@Mixin(GuiCreateWorld.class)
public abstract class ModernCreateWorld extends GuiScreen {

    @Unique
    private static Logger modernWorldCreatingUI$logger;
    @Shadow
    private GuiScreen field_146332_f; //parentScreen
    @Shadow
    private String field_146329_I; // 种子
    @Shadow
    private boolean field_146341_s; // 生成建筑
    @Shadow
    private boolean field_146338_v; // 奖励箱
    @Shadow
    private WorldSettings.GameType selectedGameType;
    @Shadow
    private WorldType field_146330_H; // 世界类型
    @Shadow
    public String field_146334_a; // 世界名称
    @Shadow
    private GuiTextField field_146335_h; // 种子输入框
    @Shadow
    private GuiTextField field_146333_g; // 世界名称输入框
    @Shadow
    private boolean field_146340_t; // 允许作弊

    @Unique
    private int modernWorldCreatingUI$difficulty;
    @Unique
    private int modernWorldCreatingUI$currentTab = 100; // 100: Game, 101: World, 102: More
    @Unique
    private final List<GuiButton> modernWorldCreatingUI$tabButtons = new ArrayList<>();
    @Unique
    private static final ResourceLocation OPTIONS_BG_LIGHT = new ResourceLocation("createworldui:textures/gui/options_background.png");
    @Unique
    private static final ResourceLocation OPTIONS_BG_DARK = new ResourceLocation("createworldui:textures/gui/options_background_dark.png");
    @Unique
    private static final ResourceLocation TABS_TEXTURE = new ResourceLocation("createworldui:textures/gui/tabs.png");
    @Unique
    private static final int TAB_WIDTH = 130;
    @Unique
    private static final int TAB_HEIGHT = 24;
    @Unique
    private EnumDifficulty modernWorldCreatingUI$selectedDifficulty = EnumDifficulty.NORMAL;

    @Inject(method = "initGui", at = @At("HEAD"), cancellable = true)
    private void initModernGui(CallbackInfo ci) {
        ci.cancel();
        Keyboard.enableRepeatEvents(true);
        this.buttonList.clear();
        this.modernWorldCreatingUI$tabButtons.clear();

        if (this.modernWorldCreatingUI$selectedDifficulty == null) {
            this.modernWorldCreatingUI$selectedDifficulty = EnumDifficulty.getDifficultyEnum(this.modernWorldCreatingUI$difficulty);
        }

        modernWorldCreatingUI$createTabButtons();

        field_146333_g = new GuiTextField(this.fontRendererObj, this.width / 2 - 100, 40, 200, 20);
        field_146333_g.setFocused(true);
        field_146333_g.setText(field_146334_a == null ? I18n.format("selectWorld.newWorld") : field_146334_a);

        field_146335_h = new GuiTextField(this.fontRendererObj, this.width / 2 - 100, 100, 200, 20);
        field_146335_h.setText(field_146329_I == null ? "" : field_146329_I);

        modernWorldCreatingUI$addButton(new GuiButton(0, this.width / 2 - 155, this.height - 28, 150, 20, I18n.format("createworldui.button.create")));
        modernWorldCreatingUI$addButton(new GuiButton(1, this.width / 2 + 5, this.height - 28, 150, 20, I18n.format("createworldui.button.cancel")));

        modernWorldCreatingUI$addTabControls();
    }

    @Unique
    private void modernWorldCreatingUI$createTabButtons() {
        int xPos = this.width / 2 - 125;
        int yPos = 5;
        String[] tabNames = {
                I18n.format("createworldui.tab.game"),
                I18n.format("createworldui.tab.world"),
                I18n.format("createworldui.tab.more")
        };

        for (int i = 0; i < 3; i++) {
            GuiButton tabButton = new GuiButton(100 + i, xPos, yPos, TAB_WIDTH, TAB_HEIGHT, tabNames[i]) {
                @Override
                public void drawButton(Minecraft mc, int mouseX, int mouseY) {
                    if (this.visible) {
                        mc.getTextureManager().bindTexture(TABS_TEXTURE);
                        boolean isHovered = mouseX >= this.xPosition && mouseY >= this.yPosition &&
                                mouseX < this.xPosition + this.width && mouseY < this.yPosition + this.height;
                        boolean isSelected = modernWorldCreatingUI$currentTab == this.id;

                        TabState state = isSelected ?
                                (isHovered ? TabState.SELECTED_HOVER : TabState.SELECTED) :
                                (isHovered ? TabState.HOVER : TabState.NORMAL);

                        drawTexturedModalRect(this.xPosition, this.yPosition, state.u, state.v, TAB_WIDTH, TAB_HEIGHT);
                        drawCenteredString(mc.fontRenderer, this.displayString,
                                this.xPosition + this.width / 2,
                                this.yPosition + (this.height - 8) / 2, state.textColor);
                    }
                }
            };
            modernWorldCreatingUI$tabButtons.add(tabButton);
            modernWorldCreatingUI$addButton(tabButton);
            xPos += TAB_WIDTH + 5;
        }
    }

    @Unique
    private void modernWorldCreatingUI$addButton(GuiButton button) {
        this.buttonList.add(button);
    }

    @Unique
    private void modernWorldCreatingUI$addTabControls() {
        this.buttonList.removeIf(button -> (button.id >= 200 && button.id < 300) || button.id == 300);

        int yPos = 140;
        switch (modernWorldCreatingUI$currentTab) {
            case 100:
                modernWorldCreatingUI$addGameTabControls(yPos);
                break;
            case 101:
                modernWorldCreatingUI$addWorldTabControls(yPos);
                break;
            case 102:
                modernWorldCreatingUI$addMoreTabControls(yPos);
                break;
        }
    }

    @Unique
    private void modernWorldCreatingUI$addGameTabControls(int yPos) {
        modernWorldCreatingUI$addButton(new GuiButton(200, this.width / 2 - 100, yPos, 200, 20,
                I18n.format("selectWorld.gameMode") + ": " + selectedGameType.getName()));
        yPos += 25;

        modernWorldCreatingUI$addButton(new GuiButton(201, this.width / 2 - 100, yPos, 200, 20,
                I18n.format("options.difficulty") + ": " +
                        I18n.format(modernWorldCreatingUI$selectedDifficulty.getDifficultyResourceKey())));
        yPos += 25;

        modernWorldCreatingUI$addButton(new GuiButton(202, this.width / 2 - 100, yPos, 200, 20,
                I18n.format("selectWorld.allowCommands") + ": " + (field_146340_t ? I18n.format("gui.yes") : I18n.format("gui.no"))));
    }

    @Unique
    private void modernWorldCreatingUI$addWorldTabControls(int yPos) {
        modernWorldCreatingUI$addButton(new GuiButton(203, this.width / 2 - 100, yPos, 200, 20,
                I18n.format("selectWorld.worldType") + ": " + field_146330_H.getWorldTypeName()));
        yPos += 25;

        modernWorldCreatingUI$addButton(new GuiButton(204, this.width / 2 - 100, yPos, 200, 20,
                I18n.format("selectWorld.mapFeatures") + ": " + (field_146341_s ? I18n.format("gui.yes") : I18n.format("gui.no"))));
        yPos += 25;

        modernWorldCreatingUI$addButton(new GuiButton(205, this.width / 2 - 100, yPos, 200, 20,
                I18n.format("selectWorld.bonusChest") + ": " + (field_146338_v ? I18n.format("gui.yes") : I18n.format("gui.no"))));
    }

    @Unique
    private void modernWorldCreatingUI$addMoreTabControls(int yPos) {
        // 只保留游戏规则编辑器按钮
        modernWorldCreatingUI$addButton(new GuiButton(300, this.width / 2 - 100, yPos, 200, 20,
                I18n.format("createworldui.button.gameRuleEditor")));
    }

    @Overwrite
    public void drawScreen(int mouseX, int mouseY, float partialTicks) {
        this.mc.getTextureManager().bindTexture(OPTIONS_BG_LIGHT);
        drawModalRectWithCustomSizedTexture(0, 0, 0, 0, this.width, this.height, 16, 16);

        this.mc.getTextureManager().bindTexture(OPTIONS_BG_DARK);

        this.drawCenteredString(this.fontRendererObj, I18n.format("selectWorld.create"), this.width / 2, 15, 0xFFFFFF);

        this.drawString(this.fontRendererObj, I18n.format("selectWorld.enterName"), this.width / 2 - 100, 27, 0xA0A0A0);
        field_146333_g.drawTextBox();

        this.drawString(this.fontRendererObj, I18n.format("selectWorld.enterSeed"), this.width / 2 - 100, 87, 0xA0A0A0);
        field_146335_h.drawTextBox();

        String tabTitle;
        switch (modernWorldCreatingUI$currentTab) {
            case 100:
                tabTitle = I18n.format("createworldui.tab.game");
                break;
            case 101:
                tabTitle = I18n.format("createworldui.tab.world");
                break;
            case 102:
                tabTitle = I18n.format("createworldui.tab.more");
                break;
            default:
                tabTitle = "";
                break;
        }
        this.drawCenteredString(this.fontRendererObj, tabTitle, this.width / 2, 120, 0xFFFFFF);

        super.drawScreen(mouseX, mouseY, partialTicks);
    }

    @Overwrite
    protected void actionPerformed(GuiButton button) {
        try {
            if (button.id == 1) {
                this.mc.displayGuiScreen(field_146332_f);
            } else if (button.id == 0) {
                modernWorldCreatingUI$saveSettingsAndCreateWorld();
            } else if (button.id >= 100 && button.id <= 102) {
                modernWorldCreatingUI$currentTab = button.id;
                modernWorldCreatingUI$addTabControls();
            } else if (button.id == 300) {
                // 打开游戏规则编辑器
                this.mc.displayGuiScreen(new GameRuleEditor(null));
            } else {
                modernWorldCreatingUI$handleTabButtonActions(button.id);
            }
        } catch (Exception e) {
            if (modernWorldCreatingUI$logger != null) {
                modernWorldCreatingUI$logger.error("Action didn't perform", e);
            }
        }
    }

    @Unique
    private void modernWorldCreatingUI$handleTabButtonActions(int buttonId) {
        switch (buttonId) {
            case 200:
                selectedGameType = WorldSettings.GameType.getByID((selectedGameType.getID() + 1) % 4);
                break;
            case 201:
                EnumDifficulty[] difficulties = EnumDifficulty.values();
                int nextOrdinal = (modernWorldCreatingUI$selectedDifficulty.ordinal() + 1) % difficulties.length;
                modernWorldCreatingUI$selectedDifficulty = difficulties[nextOrdinal];
                this.modernWorldCreatingUI$difficulty = modernWorldCreatingUI$selectedDifficulty.getDifficultyId();
                break;
            case 202:
                field_146340_t = !field_146340_t;
                break;
            case 203:
                WorldType[] worldTypes = WorldType.worldTypes;
                int currentId = field_146330_H.getWorldTypeID();
                int nextId = (currentId + 1) % worldTypes.length;
                if (worldTypes[nextId] != null) {
                    field_146330_H = worldTypes[nextId];
                }
                break;
            case 204:
                field_146341_s = !field_146341_s;
                break;
            case 205:
                field_146338_v = !field_146338_v;
                break;
            // 删除了 206, 207, 208 对应的 case
        }
        modernWorldCreatingUI$addTabControls();
    }

    @Unique
    private void modernWorldCreatingUI$saveSettingsAndCreateWorld() {
        field_146334_a = field_146333_g.getText().trim();
        field_146329_I = field_146335_h.getText().trim();

        long seed = field_146329_I.isEmpty() ? System.currentTimeMillis() :
                field_146329_I.matches("-?\\d+") ? Long.parseLong(field_146329_I) : field_146329_I.hashCode();

        WorldSettings settings = new WorldSettings(
                seed,
                selectedGameType,
                field_146341_s,
                field_146338_v,
                field_146330_H
        );

        if (field_146340_t) {
            settings.enableCommands();
        }

        if (field_146338_v) {
            settings.enableBonusChest();
        }

        createWorld(settings);
    }

    @Inject(method = "createWorld", at = @At("RETURN"))
    private void onWorldCreated(WorldSettings settings, CallbackInfo ci) {
        try {
            Object integratedServer = Minecraft.getMinecraft().getIntegratedServer();
            if (integratedServer != null) {
                Method getWorldMethod = integratedServer.getClass().getMethod("getWorld", int.class);
                Object world = getWorldMethod.invoke(integratedServer, 0);

                Method getWorldInfoMethod = world.getClass().getMethod("getWorldInfo");
                WorldInfo worldInfo = (WorldInfo) getWorldInfoMethod.invoke(world);

                worldInfo.setDifficulty(modernWorldCreatingUI$selectedDifficulty);
            }
        } catch (Exception e) {
            if (modernWorldCreatingUI$logger != null) {
                modernWorldCreatingUI$logger.error("Failed to set difficulty after world creation", e);
            }
        }
    }

    @Shadow
    private void createWorld(WorldSettings settings) {}

    @Unique
    private String modernWorldCreatingUI$getDifficultyName() {
        EnumDifficulty currentDifficulty = EnumDifficulty.getDifficultyEnum(this.modernWorldCreatingUI$difficulty);
        return I18n.format(currentDifficulty.getDifficultyResourceKey());
    }

    @Override
    protected void keyTyped(char typedChar, int keyCode) {
        field_146333_g.textboxKeyTyped(typedChar, keyCode);
        field_146335_h.textboxKeyTyped(typedChar, keyCode);
        if (keyCode == 1) {
            this.mc.displayGuiScreen(field_146332_f);
        }
    }

    @Override
    protected void mouseClicked(int mouseX, int mouseY, int mouseButton) {
        super.mouseClicked(mouseX, mouseY, mouseButton);
        field_146333_g.mouseClicked(mouseX, mouseY, mouseButton);
        field_146335_h.mouseClicked(mouseX, mouseY, mouseButton);
    }
}